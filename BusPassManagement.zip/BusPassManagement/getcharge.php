<?php
include('dbconnection.php');
session_start();
if (isset($_GET['place'])) {
    $selectedPlace = mysqli_real_escape_string($con, $_GET['place']);
    $selectedType = mysqli_real_escape_string($con, $_GET['type']);
    $query = "SELECT pcharge FROM place WHERE pname = '$selectedPlace'";
    $result = mysqli_query($con, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        if($_SESSION["passtype"]=="monthly")
        {
            if($selectedType=="ac")
            {
                $price=($row['pcharge']*30)*2;
                echo $price;
            }
            elseif($selectedType=="nac")
            {
                $price=$row['pcharge']*30;
                echo $price;
            }
            
        }
        elseif($_SESSION["passtype"]=="weekly")
        {
            if($selectedType=="ac")
            {
                $price=$row['pcharge']*7*2;
                echo $price;
            }
            elseif($selectedType=="nac")
            {
                $price=$row['pcharge']*7;
                echo $price;
            }
        }
        
    } else {
        echo "Error fetching price";
    }
} else {
    echo "Invalid request";
}
?>

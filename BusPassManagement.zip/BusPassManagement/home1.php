<?php
include_once ('hello.php');
?>
<!DOCTYPE html>
<html>
    <head><link rel="stylesheet" href="style.css"></head>
<body>

</body>
</html>


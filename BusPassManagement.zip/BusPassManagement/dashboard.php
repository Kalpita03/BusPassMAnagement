<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style2.css">
<body>

<div class="sidenav">
    <br><br>
  <a href="adminDashboard.php">Dashboard</a>
  <a href="addPassenger.php">Add Pass</a>
  <a href="#">Services</a>
  <a href="#">Clients</a>
  <a href="#">Contact</a>
</div>

<div class="main">
  
</div>
   
</body>
</html> 

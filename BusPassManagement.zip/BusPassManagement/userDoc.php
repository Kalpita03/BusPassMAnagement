<?php
include('dbconnection.php');
session_start();
$uid=$_SESSION['uid'];
$pid=$_SESSION['pid'];
if(isset($_POST["next"]))
{
  $name=$_POST["name"];
  $bdate=date('d-m-Y', strtotime($_POST["bdate"]));
  $gender=$_POST['gender'];
  $contact=$_POST['contact'];
  $email=$_POST['email'];
  $occu=$_POST['occu'];
  $cat=$_POST['cat'];
  $from=$_POST['from'];
  $des=$_POST['des'];
  $charge=$_POST['charge'];
  $sql="insert into user_details(uid,pid,ubdate,ugender,uoccu,ucat,ufrom,udes,ucharge) values($uid,$pid,'$bdate','$gender','$occu','$cat','$from','$des',$charge)";
  $res=mysqli_query($con,$sql);
  if(!$res)
  {
    echo "not inserted";
  }
  
}

elseif(isset($_POST["register"]))
{

$pno='P2024'.$uid.$pid;

$filename = $_FILES["uploadfile"]["name"];
$tmpname = $_FILES["uploadfile"]["tmp_name"];
//print_r($_FILES["uploadfile"]);
$folder = "UserImg/".$uid.'_'.$filename;
move_uploaded_file($tmpname, $folder);

//for documents
$documentname = $_FILES["document"]["name"];
$dtmpname = $_FILES["document"]["tmp_name"];
//print_r($_FILES["uploadfile"]);
$dfolder = "UserDoc/".$uid.'_'.$documentname;
move_uploaded_file($dtmpname, $dfolder);

$id=$_POST["id"];
$idno=$_POST["idno"];


$sql="update user_details set upass_no='$pno',uimg='$folder',uid_type='$id',uid_no='$idno',uid_img='$dfolder' where uid=$uid";
  $res=mysqli_query($con,$sql);
  if(!$res)
  {
    echo "not inserted";
  }
  else{
    header('location:userstatus.php');
 
  }
}
else{
  #header("location:userRegistration.php");
  
}

?>



<!DOCTYPE html>
<html>
    <head>
    <link rel="stylesheet" href="stylef.css">

</head>
<body >
<header>
        <h1>Bus Pass Management System</h1>
    </header>


<div class="main">
<section class="container">
        
<form action="#" method="post" enctype="multipart/form-data" border="2px" >
  <h2 style="text-decoration-line: underline" align="center">Upload Documents</h2>

  <label for="photo">Upload Photo:</label>
  <input type="file" name="uploadfile" id="img" >

  
  </select><br><br>
  <label for="identity">Identity Type:</label>
  <select name="id" id="id" required>
  <option value="VoterCard">Voter Card</option>
  <option value="PanCard">Pan Card</option>
  <option value="AdharCard">Adhar Card</option>
  <option value="StudentCard">Student Card</option>
  </select><br><br>
  <label for="idno">Identity No.:</label>
  <input type="text" id="idno" name="idno"><br><br>
  <label for="identitycard">Identity Card Upload:</label>
  <input type="file" name="document" id="document" required>
  </select><br><br>
  <center><input type="submit" name="register" value="SUBMIT" style="font-weight:bold"></center>
</form>


    </section>

</div>

</div>

</body>
</html>
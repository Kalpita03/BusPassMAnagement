<?php
$con=mysqli_connect("localhost","root","","db_pass2");
if(!$con)
{
    echo "Connection Failed";
}
else{
    //echo "Connection Success";
}
?>
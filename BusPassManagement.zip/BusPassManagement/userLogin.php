<?php
session_start();
include('dbconnection.php');

// if(isset($_GET['sid']))
// {
//     $_SESSION['suid']=$_GET['sid'];
// }

?>

<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Login/Register</title>
        <link rel="stylesheet" href="homecss.css">
        <link rel="stylesheet" href="login2.css">
        
       
    </head>
<body>
  
<header>
        <h1>Bus Pass Management System</h1>
    </header>

    <nav>
        <a href="mainhome.php">Home</a>
        
        <a href="aboutus.php">About Us</a>
        <a href="contactus.php">Contact Us</a>
    </nav>
        <section class="container">
            <form name="frm" action="#" method="post">
                <a href="userhome2.php"><h2 style="color: orangered">LOGIN</h2></a>
                <br>
                <h3>Sign In</h3>
                <input type="text" placeholder="Email" name="email" required>
                <input type="password" placeholder="Password" name="password" required>
                <a>
                <input type="submit" value="Login" name="login">
                </a>
                <br><br>
                <h4 style="color: black">Dont Have an Account ?</h4>
                <a href='userregistration.php' style='color: redorange'>Sign Up</a>
            </form>

           
            <?php
           /* if(isset($_GET['sid']))
            {
                $_SESSION['suid']=$_GET['sid'];
                $id=$_SESSION['suid'];
                echo"<a href='userRegistration.php?sid=$id' style='color: redorange'>Sign Up</a>";
            }
            else
            {
                 echo"<a href='registration.php' style='color: redorange'>Sign Up</a>";
            } 
            // <a href="userReg.php" style="color: redorange">*/
            ?>
            <!-- Sign Up
          </a> -->
          </section>
        </div>
      </div>
      </div>
          </div>
      <?php
        if(isset($_POST["login"]))
        {
          $email = $_POST["email"];
          $password = $_POST["password"];
           $qry = "select * from user where uemail = '$email' && upswd = '$password'";
          $res = mysqli_query($con,$qry);
          $cnt = mysqli_num_rows($res);
          
            
          if($cnt>=1)
          {
            $row = mysqli_fetch_row($res);
            echo $r=$row[1];
            //$_SESSION["uid"] = $row[0];
           // die(0);
            echo $uid= $row[0];
           // $_SESSION["u_name"] = $row[1];
            if($r==0)
            {
              echo $qry="select uid from user where utype=$r";
              $res=mysqli_query($con,$qry);
              $arow=mysqli_fetch_assoc($res);
              $_SESSION["a_id"]=$arow[0];
                header("location:adminDashboard.php?uid=$uid");

            }
            if($r==1)
            {
               $qry="select uid from user where utype=$r";
              
              $res=mysqli_query($con,$qry);
              $arow=mysqli_fetch_row($res);
              
              $_SESSION["uid"]=$arow[0];
                header("location:userhome.php?uid=$uid");

            }
            /*if(isset($_GET['sid']))
            {
                $_SESSION['suid']=$_GET['sid'];
                header("location:userhome2.php");
            }*/
           
            
          }
          else
          {
            echo "failed";
          }
        }
      ?>
      
</body>
</html>
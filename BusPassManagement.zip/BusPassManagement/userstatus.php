<?php
include('dbconnection.php');
session_start();
$id=$_SESSION['uid'];
$p="Paid";
//echo $pid=$_SESSION['pid'];
//if(!$pid)
/*{
    echo "pass yet not booked";
}*/
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bus Pass Management System</title>
    <link rel="stylesheet" href="stylef.css">
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

       
        input[type=button]{
            padding: 10px;
            margin-top:10px;
            background-color:#add8e6;
            border-radius: 10px;
            cursor: pointer;
        } 
        </style>
   
      
</head>
<body>

    <header>
        <h1>Bus Pass Management System</h1>
    </header>

    <nav>
    <a href="userhome.php">Home</a>
        <a href="userstatus.php">Status</a>
        <?php
       
        $qry="select pid from user_details where uid=$id";
        $res=mysqli_query($con,$qry);
        $row=mysqli_num_rows($res);
        if($row >0)
        {
            echo "<a>Purchase Pass</a>";
        }
        
        else
        {
           echo "<a href='purchasepass.php'>Purchase Pass</a>";
        }
        ?>
        <a href="userProfile.php">Profile</a>
        <a href="logout.php">Logout</a>
    </nav>

    <section class="container">
        
        <table>
        <thead>
            <tr>
                <th>Pass_ID</th>
                <th>Pass Type</th>
                <th>From</th>
                <th>To</th>
                <th>Valid From</th>
                <th>Valid Upto</th>
                <th>Status</th>
                <th>Pay</th>
            </tr>
        </thead>
        <tbody>
            <tr>
            <?php
          
             $qry="select * from user_details where uid=$id";
             $res=mysqli_query($con,$qry);
             $row = mysqli_fetch_assoc($res);
            
            
             $pqry="select * from pass_detail where uid=$id";
             $pres=mysqli_query($con,$pqry);
             $prow = mysqli_fetch_assoc($pres);
             $pno=$row["upass_no"];

             //date calculation
            $dateString=$prow["pdate"];
            // Create a DateTime object from the string
            $dateObject = DateTime::createFromFormat('d-m-Y', $dateString);


            $pqry1="select pid from user_details where uid=$id";
            $pres1=mysqli_query($con,$pqry1);
            $prow1=mysqli_fetch_row($pres1);

            $mqry="select ptype from pass_detail where pid=$prow1[0]";
            $mres=mysqli_query($con,$mqry);
            $mrow=mysqli_fetch_row($mres);

            if($mrow[0]=="monthly")
            {
                $thirtyDaysAfter = $dateObject->modify('+30 days')->format('d-m-Y');
                $iqry="update pass_detail set penddate='$thirtyDaysAfter' where pid=$prow1[0]";
                $ires=mysqli_query($con,$iqry);    

            }
            else if($mrow[0]=="weekly")
            {
                $thirtyDaysAfter = $dateObject->modify('+7 days')->format('d-m-Y');
                $iqry="update pass_detail set penddate='$thirtyDaysAfter' where pid=$prow1[0]";
                $ires=mysqli_query($con,$iqry);
            }
           
            
           
            {

                   echo "<tr>";
                   echo "<td>".$row["upass_no"] ."</td>";
                   echo "<td>".$prow["ptype"] ."</td>";
                   echo "<td>".$row["ufrom"] ."</td>";
                   echo "<td>".$row["udes"] ."</td>";
                   echo "<td>".$prow["pdate"] ."</td>";
                   echo "<td>".$thirtyDaysAfter."</td>";
                   if($row["ustatus"]==0)
                   {
                    echo "<td>Not Approved</td>";
                    
                   }
                   else{
                    echo "<td>Approved</td>";
                   }
                if($row["upaid"]==0)
                {
                   if($row["ustatus"]==0)
                   {
                    echo "<td><input type='button' value='Pay' disabled></td>";

                   }
                   elseif(($row["ustatus"]==1)){
                    echo "<td><a href='userPayment.php?pno=$pno'><input type='button' value='Pay' ></a></td>";
                   }
                }
                else
                {
                    echo "<td>$p</td>";
                }
                   
                   echo "</tr>";
                
                }
        ?>
        </tbody>
    </table>
<!------------------------------->
   
    </section>

</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bus Pass Management System - Home</title>
    <link rel="stylesheet" href="demo.css">
</head>
<body>

    <header>
        <div class="hero">
            <h1>Welcome to Bus Pass Management System</h1>
           
        </div>
    </header>

    <nav>
    <a href="mainhome.php">Home</a>
    <a href="aboutus.php">About Us</a>
    <a href="contactus.php">Contact Us</a>
        
        <a href="userlogin.php">Login</a>
    </nav>

    <section class="services">
       
        <div class="service">
            <h3>Our Mission</h3>
            <p>At the heart of our mission is the desire to simplify and enhance the bus pass management experience for both administrators and users. We aim to leverage technology to create a seamless and reliable system that ensures a hassle-free journey for everyone involved.</p>
        </div>
        <div class="service">
            <h3>Responsive Customer Support</h3>
            <p>Our dedicated customer support team is ready to assist you with any queries or concerns. We believe in building lasting relationships and providing ongoing support to ensure the success of your bus pass management system.</p>
        </div>
       
    </section>

    
   
    
</body>
</html>

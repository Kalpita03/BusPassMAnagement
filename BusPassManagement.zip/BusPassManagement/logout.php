<?php
include("dbconnection.php");
session_unset();
session_destroy();
header('location:mainhome.php');
?>
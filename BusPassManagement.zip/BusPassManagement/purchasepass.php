<?php

include('dbconnection.php');
session_start();
$uid=$_SESSION['uid'];
if(!$uid)
{
    header('location:userLogin.php');
}
if(isset($_POST["next"]))
{
    $ptype=$_POST["passType"];
    $_SESSION['passtype']=$_POST["passType"];
    $pdate = date('d-m-Y', strtotime($_POST["start_date"]));
    echo $qry="insert into pass_detail(uid,pdate,ptype) values($uid,'$pdate','$ptype')";
    $res=mysqli_query($con,$qry);
   
    if($res)
    {
        echo $rqry="select pid from pass_detail where uid=$uid";
        $rres=mysqli_query($con,$rqry);
        $rrow=mysqli_fetch_row($rres);
        $_SESSION['pid']=$rrow[0];
        header('location:newpass.php');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bus Pass Management System</title>
    <link rel="stylesheet" href="stylef.css">
    
      
</head>
<body>

    <header>
        <h1>Bus Pass Management System</h1>
    </header>

    <nav>
       <a href="userhome.php">Home</a>
        <a href="userstatus.php">Status</a>
        <a href="purchasepass.php">Purchase Pass</a>
        <a href="userProfile.php">Profile</a>
        <a href="logout.php">Logout</a>
    </nav>

    <section class="container">
        <?php
         $qry="select uname from user where uid=$uid";
         $res=mysqli_query($con,$qry);
         $row=mysqli_fetch_row($res);
        
        ?>
        <h2>Welcome, <?php echo $row[0]?>!</h2>
       
        <form method="post" action="#">
    <!-- Your form fields go here -->
    <label for="passType">Select Pass Type:</label>
            <select id="passType" name="passType">
                <option value="monthly">Monthly Pass</option>
                <option value="weekly">Weekly Pass</option>
                <!-- Add more options as needed -->
            </select>
    <label for="start_date">Start Date:</label>
    <input type="date" name="start_date" id="start_date" required>

    
    <button type="submit" name="next" value="NEXT">NEXT</button>

    <script>
        // Get the current date in the format "YYYY-MM-DD"
        var currentDate = new Date().toISOString().split('T')[0];
       

        // Set the min attribute for both date inputs
        document.getElementById('start_date').min = currentDate;
       
    </script>
</form>
    </section>

</body>
</html>

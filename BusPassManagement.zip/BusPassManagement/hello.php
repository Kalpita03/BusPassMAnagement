<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style.css">
<style>
body {
  background-image:url("img/homepage.jpg");
  height: 100%; 

  /* Center and scale the image nicely */
  
  background-repeat: no-repeat;
  background-size: cover;
}
</style>
</head>
<body>

<div class="topnav">
  <a class="active" href="hello.php">Home</a>
  <a href="#news">News</a>
  <a href="#contact">Contact</a>
  <a href="#about">About</a>
  <a href="userLogin.php"><img src="img/login.png" height="25px" width="25px"></img></a>
</div>

<div style="padding-left:16px">
  
</div>

</body>
</html>

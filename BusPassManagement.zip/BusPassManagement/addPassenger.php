<?php
include_once ('dashboard.php');
?>
<!DOCTYPE html>
<html>
    <head><link rel="stylesheet" href="style.css"></head>
<body style="background-color:grey">

<div class="main">

<form action="/action_page.php" method="get" target="_blank" >
  <h2 style="text-decoration-line: underline" align="center">Personal Details</h2>
  
  <label for="fname">Name:</label>
  <input type="text" id="fname" name="fname"><br><br>
  <label for="fname">Profile:</label>
  <input type="file" name="fileToUpload" id="fileToUpload"><br><br>
  <label for="fname">Contact:</label>
  <input type="text" id="fname" name="fname"><br><br>
  <label for="fname">Email-id:</label>
  <input type="text" id="fname" name="fname"><br><br>
  <label for="fname">Identity Type:</label>
  <select name="cars" id="cars">
  <option value="volvo">Volvo</option>
  <option value="saab">Saab</option>
  <option value="mercedes">Mercedes</option>
  <option value="audi">Audi</option>
  </select><br><br>
  <label for="fname">Identity No.:</label>
  <input type="text" id="fname" name="fname"><br><br>
  <label for="fname">Category:</label>
  <select name="cars" id="cars">
  <option value="volvo">Volvo</option>
  <option value="saab">Saab</option>
  <option value="mercedes">Mercedes</option>
  <option value="audi">Audi</option>
  </select><br><br>
  <label for="fname">From:</label>
  <input type="text" id="fname" name="fname"><br><br>
  <label for="fname">Destination:</label>
  <input type="text" id="fname" name="fname"><br><br>
  <label for="lname">From Date:</label>
  <input type="date" id="lname" name="lname"><br><br>
  <label for="lname">To Date:</label>
  <input type="date" id="lname" name="lname"><br><br>
  <center><input type="submit" value="Submit using GET"></center>
  
</form>
</div>

</body>
</html>


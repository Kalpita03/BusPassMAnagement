<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bus Pass Management System - Home</title>
    <link rel="stylesheet" href="demo.css">
</head>
<body>

    <header>
        <div class="hero">
            <h1>Welcome to Bus Pass Management System</h1>
           
        </div>
    </header>

    <nav>
        <a href="#">Home</a>
        
        <a href="aboutus.php">About Us</a>
        <a href="contactus.php">Contact Us</a>
        <a href="userlogin.php">Login</a>
    </nav>

    <section class="services">
        <h2>Our Services</h2>
        <div class="service">
            <h3>Easy Online Booking</h3>
            <p>Book your bus passes conveniently online.</p>
        </div>
        <div class="service">
            <h3>Flexible Pass Options</h3>
            <p>Choose from a variety of pass options that suit your needs.</p>
        </div>
        <div class="service">
            <h3>24/7 Customer Support</h3>
            <p>Our customer support team is available around the clock to assist you.</p>
        </div>
    </section>

    
   
    
</body>
</html>

<?php
include('dbconnection.php');
session_start();
$uid=$_SESSION["uid"];
if(isset($_GET["pno"]))
{
    $pno=$_GET['pno'];
    $qry="select ucharge from user_details where upass_no='$pno'";
    $res=mysqli_query($con,$qry);
    $row=mysqli_fetch_row($res);
    $charge=$row[0];
   
}
if(isset($_POST["pay"]))
{

    $cn=$_POST["card-number"];
    $ed=$_POST["expiry-date"];
    $cvv=$_POST["cvv"];
    $name=$_POST["name-on-card"];
   
    
   $qry="insert into upayment_details value('$pno',$uid,'$cn','$ed','$cvv','$name')";
    $res=mysqli_query($con,$qry);
   
    //update payment status
    
    if(!$res)
    {
        echo "not inserted";
    }
    else
    {
       $uqry="update user_details set upaid=1 where upass_no='$pno'";
       $ures=mysqli_query($con,$uqry);
       header('location:userstatus.php');
        //echo "inserted";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Page</title>
    <link rel="stylesheet" href="stylepay.css">
</head>
<body>

<div class="payment-container">
    <form method="post" action="#" id="payment-form">
        <h2>Payment Details</h2>
        
        <label for="card-number">Card Number:</label>
        <input type="text" id="card-number" name="card-number" placeholder="1234 5678 9012 3456" required title="enter in 1234 3456 5678 8765 format" pattern="^\d{4} \d{4} \d{4} \d{4}$" >

        <label for="expiry-date">Expiry Date:</label>
        <input type="text" id="expiry-date" name="expiry-date" pattern="^(0[1-9]|1[0-2])(\d{2})$" title="enter in mm/yy format" placeholder="MM/YY" required>

        <label for="cvv">CVV:</label>
        <input type="text" id="cvv" name="cvv" placeholder="123" pattern="[1-9]{3}" required>

        <label for="name-on-card">CardHolder Name:</label>
        <input type="text" id="name-on-card" name="name-on-card" pattern="[A-Za-z ]{3,}" title="enter only alphabets" required>

        <label >Amount:</label>
        <input type="text" id="amount" name="amount" value="<?php echo $charge;?>" readonly>
        <button type="submit" name="pay">Submit Payment</button>
    </form>
</div>

</body>
</html>

<?php
include('dbconnection.php');


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bus Pass Management System</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }
   
        </style>
   
    
      
</head>
<body>

<div style="width: 100%; height:100%;">  
        <div style="background-color: grey; width: 100%; height: 20%;">  
 
<div class="row" style="display:flex; margin-left:20%;">

<div>
    <a href="passDetail.php"><img src="img/busPass.png" alt="Approved Pass"  height="120px" width="120px"></a>
  <br>
  
    
  </div>
  <div style="padding-left:100px;" >
    <a href="notApproved.php"><img src="img/pending1.png" alt="Pending" height="120px" width="120px" ></a>
    <br>
   
  </div>
  <div style="padding-left:100px;" >
    <a href="Approved.php"><img src="img/approve.png" alt="Approved" height="120px" width="120px"></a>
  </div>
  <div style="padding-left:100px;" >
    <a href="logout.php"><img src="img/Logout.jpg" alt="Logout" height="120px" width="120px"></a>
  </div>
  
</div>

        </div>  
        <div style="width:100%; height: 80%;">  
        <br>
        <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>PassNo</th>
                <th>Name</th>
                <th>Email</th>
                <th>Occupation</th>
                <th>From</th>
                <th>To</th>
                <th>Valid From</th>
                <th>Valid Upto</th>
                <th>Pass Type</th>
                <th>Image</th>
                <th>Document</th>
                
            </tr>
        </thead>
        <tbody>
            <tr>
            <?php
            $qry = "select uid from user_details where upaid = 1";
            $res = mysqli_query($con,$qry);
            while($frow = mysqli_fetch_row($res))
            {
                $uqry = "select * from user_details where uid = $frow[0]";
                $ures = mysqli_query($con,$uqry);
                

               
                
                
                while($urow = mysqli_fetch_assoc($ures))
                { 
                    //user info
                    $id=$urow['uid'];
                    $pqry="select * from user where uid = $id";
                    $pres=mysqli_query($con,$pqry);
                    $prow=mysqli_fetch_assoc($pres);

                  //pass
                    $rqry="select * from pass_detail where uid = $id";
                    $rres=mysqli_query($con,$rqry);
                    $rrow=mysqli_fetch_assoc($rres);

                   echo "<tr>";
                   echo "<td>".$urow["uid"] ."</td>";
                   echo "<td>".$urow["upass_no"] ."</td>";
                   echo "<td>".$prow["uname"] ."</td>";
                   echo "<td>".$prow["uemail"] ."</td>";
                   echo "<td>".$urow["uoccu"] ."</td>";
                   echo "<td>".$urow["ufrom"] ."</td>";
                   echo "<td>".$urow["udes"] ."</td>";
                   echo "<td>".$rrow["pdate"] ."</td>";
                   echo "<td>".$rrow["penddate"] ."</td>";
                   echo "<td>".$rrow["ptype"] ."</td>";
                   echo "<td><img src='" . $urow["uimg"] . "' height='100px' width='150px'></td>";
                   echo "<td><a href='".$urow["uid_img"]."' target='_blank'>View</a></td>";
                   
                   echo "</tr>";
                }
            }

        ?>
        </tbody>
    </table>

        </div>  
    </div>  
</body>
</html>

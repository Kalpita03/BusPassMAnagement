<?php
include('dbconnection.php');
session_start();
if(isset($_GET["uid"]))
{
 $_SESSION["uid"]=$_GET['uid'];
    
}
$id=$_SESSION["uid"];
if(!$id)
{
    header('location:userLogin.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bus Pass Management System - Home</title>
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: #333;
        }

        header {
            background-color: #2c3e50;
            color: #fff;
            padding: 1em;
            text-align: center;
        }
        nav {
            background-color: #34495e;
            color: #fff;
            padding: 1em;
            text-align: center;
        }

        nav a {
            color: #fff;
            text-decoration: none;
            padding: 1em;
            margin: 0 1em;
            font-size: 18px;
            transition: color 0.3s ease;
        }

        nav a:hover {
            color: #ecf0f1;
        }

        
        section.hero {
            background: url('img/homepage.jpg') center/cover no-repeat;
            filter:blur(2px);
            color: #fff;
            text-align: center;
            padding: 100px 0;
            height: 50vh; /* Set the height to 100% of the viewport height */
            display: flex;
            flex-direction: column;
            justify-content: center;
            
        }

        .hero h1 {
            font-size: 48px;
            font-weight:bold;
            margin-bottom: 20px;
            
        }

        .hero p {
            font-size: 18px;
            margin-bottom: 40px;
        }

        .container {
            max-width: 1000px;
            margin: auto;
        }

        
        
        
    </style>
</head>
<body>

    <header>
        <h1>Bus Pass Management System</h1>
    </header>

    <nav>
        
        <!--<a href="#">My Passes</a>-->
        <?php
        $qry="select pid from user_details where uid=$id";
        $res=mysqli_query($con,$qry);
        $row=mysqli_num_rows($res);
       
        if($row >0)
        {
            echo "<a>Purchase Pass</a>";
        }
        
        else
        {
           echo "<a href='purchasepass.php'>Purchase Pass</a>";
        }
        ?>
        
        <a href="userstatus.php">Pass Status</a>
        <a href="userProfile.php">Profile</a>
        <a href="logout.php">Logout</a>
    </nav>

    <section class="hero">
        <div class="container">
            <h1>Enjoy Hassle-Free Bus Travel</h1>
            <p>Get your bus pass today and experience convenient and efficient travel.</p>
            
    </div>
    </section>
</body>
</html>

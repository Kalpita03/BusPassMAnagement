<?php
//include ('dashboard.php');
include ('dbconnection.php');
session_start();
if(isset($_GET["uid"]))
{
 $_SESSION["uid"]=$_GET['uid'];
    
}

?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="style2.css">
<style>


</style>
</head>
<body style="background-color:grey">
<div class="main">

<div class="row">
  <div class="column">
  <a href="passDetail.php"> <img src="img/busPass.png" alt="Approved Pass"  height="150px" width="150px"></a>
  <br>
  Total Pass
</div>
  <div class="column">
    <a href="notApproved.php"><img src="img/request.png" alt="Pending" height="150px" width="150px" ></a>
    <br>
    Pending
  </div>
  <div class="column">
  <a href="Approved.php"><img src="img/approve.png" alt="Approved" height="150px" width="150px"></a>
  <br>
  Approved
  </div>
  <div class="column">
  <a href="logout.php"><img src="img/Logout.jpg" alt="Logout" height="150px" width="150px"></a>
  <br>
 Logout
  </div>
  
  
</div>
</div>
</body>
</html>

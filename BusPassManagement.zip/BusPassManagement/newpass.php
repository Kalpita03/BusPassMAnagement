<?php
include('dbconnection.php');
session_start();
$uid = $_SESSION['uid'];

$sqry = "SELECT pname, pcharge FROM place";
$result = mysqli_query($con, $sqry);
$pid=$_SESSION['passtype'];
$_SESSION['pid'];
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="stylef.css">
</head>
<body>
    <header>
        <h1>Bus Pass Management System</h1>
    </header>

    <div class="main">
        <section class="container">
            <form name="frm" action="userDoc.php" method="post">
                <div class="border">
                    <h2 style="text-decoration-line: underline" align="center">Personal Details</h2>
                    <?php
                    $qry = "select * from user where uid=$uid";
                    $res = mysqli_query($con, $qry);
                    $row = mysqli_fetch_row($res);
                    ?>
                    <label for="name">Name:</label>
                    <input type="text" id="name" name="name" value="<?php echo $row[2];?>" readonly><br><br>
                    <label for="bdate">BirthDate:</label>
                    <input type="date" id="bdate" name="bdate" max="<?= date('Y-m-d'); ?>" required><br><br>
                    <label for="gender">Gender : </label>
                    Male<input type="radio" class="radio" name="gender" id="male" required>
                    Female<input type="radio" name="gender" id="female" value="female" required><br>
                    <label for="contact">Contact:</label>
                    <input type="text" id="contact" name="contact" value="<?php echo $row[3];?>" readonly><br><br>
                    <label for="email">Email-id:</label>
                    <input type="email" id="email" name="email" value="<?php echo $row[4];?>" readonly></span><br><br>
                    <label for="fname">Occupation:</label>
                    <select name="occu" id="occu">
                        <option value="Employee">Employee</option>
                        <option value="Student">Student</option>
                    </select><br><br>
                    <label for="cat">Category:</label>
                    <select name="cat" id="cat" required>
                        <option value="ac">AC</option>
                        <option value="nac">Non-AC</option>
                    </select><br><br>
                    <label for="from">From:</label>
                    <input type="text" id="from" name="from" value="Anand" readonly><br><br>
                    <label for="des">Destination:</label>
                    <?php
                    if (mysqli_num_rows($result) > 0) {
                        echo "<select name='des' id='des' onchange='updateCharge()'>";
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<option value='" . $row["pname"] . "'>" . $row["pname"] . "</option>";
                        }
                        echo "</select>";
                    }
                    ?>
                    <br><br>
                    <label for="charge">Charge:</label>
                    <input type="text" id="charge" name="charge" value="" readonly><br><br>
                    <center><input type="submit" name="next" value="NEXT" style="font-weight:bold"></center>
                    <center><a href="purchasepass.php"><label name="back" >BACK</label></a></center>
                </div>
            </form>
            
        </section>
    </div>

    <script>
        function updateCharge() {
            var selectedPlace = document.getElementById("des").value;
            var selectedType=document.getElementById("cat").value;
            var xhttp = new XMLHttpRequest();
            
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("charge").value = this.responseText;
                }
            };
            var url = "getCharge.php?place=" + selectedPlace + "&type=" + selectedType;
            xhttp.open("GET", url, true);
            xhttp.send();
        }
    </script>
</body>
</html>

<?php
include ('dbconnection.php');
if(isset($_POST["register"]))
{
    $name=$_POST["name"];
    $contact=$_POST["contact"];
    $email=$_POST["email"];
    $pswd=$_POST["pswd"];
    
   $qry = "insert into user(utype,uname,uemail,ucontact,upswd) values(1,'$name','$email',$contact,'$pswd')";
    $res = mysqli_query($con,$qry);
    if(!$res)
    {
        echo "Insertion failed";
    }
    else{
        header('location:userlogin.php');
    }
}

// Define variables to store user input and error messages
$password = $confirmPassword = $passwordErr = "";

// Check if the form is submitted
if (isset($_POST["submit"])) {
    // Validate password
    if (empty($_POST["pswd"])) {
        $passwordErr = "Password is required";
    } else {
        $password = $_POST["pswd"];
    }

    // Validate confirm password
    if (empty($_POST["rpswd"])) {
        $passwordErr = "Confirm Password is required";
    } else {
        $confirmPassword = $_POST["rpswd"];
    }

    // Check if passwords match
    if ($password != $confirmPassword) {
        $passwordErr = "Passwords do not match";
    }

    // If no validation errors, proceed with further processing
    if (empty($passwordErr)) {
        // Perform necessary actions, e.g., store password in the database
        // ...
        //echo "Password successfully validated and processed!";
        header('location:userLogin.php');

    }
}


?>
<!DOCTYPE html>
<html>
    <head> 
    <link rel="stylesheet" href="stylef.css">

</head>
<body >
    
<header>
        <h1>Bus Pass Management System</h1>
    </header>

    <nav>
    <a href="mainhome.php">Home</a>
        
        <a href="aboutus.php">About Us</a>
        <a href="contactus.php">Contact Us</a>
        <a href="userLogin.php">Login</a>
    </nav>
    <section class="container">
<form name="frm" action="#" method="post"><div class="border">
  
  <label for="name">Name:</label>
  <input type="text" id="name" name="name"  required pattern="[A-Za-z ]{3,}" title="Please enter alphabets only" ><br><br>

  
 
  <label for="contact">Contact:</label>
  <input type="text" id="contact" name="contact"  required pattern="[^0][1-9]{9}" title="Please enter a 10-digit number not starting with 0" ><br><br>
  <label for="email">Email-id:</label>
  <input type="email" id="email" name="email" required></span><br><br>
  
  <label for="from">Password</label>
  <input type="password" id="pswd" name="pswd" ><br><br>
  <label for="from">Confirm-Password</label>
  <input type="password" id="rpswd" name="rpswd" ><span class="error"><?php echo $passwordErr; ?></span><br><br>
  <center><input type="submit" name="register" value="Register" ></center>

</form>
    </section>
</body>
</html>
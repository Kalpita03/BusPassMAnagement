<?php
include('dbconnection.php');

session_start();
 $id=$_SESSION["uid"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <style>
       
        #profile-container {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            width: 600px;
            text-align: center;
            
            margin: 20px auto;
            
        }

        #profile-header {
            background-color:  #2c3e50;
            color: #fff;
            padding: 20px;
        }

        #profile-image {
            width: 150px;
    height: 150px;
    object-fit: cover;
    border-radius: 50%;
    margin-top: -75px;
    border: 5px solid #fff;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        #user-details {
            padding: 20px;
        }

        #user-details h2 {
            margin-bottom: 10px;
            color: #333;
        }

        #user-details p {
            margin-bottom: 5px;
        }


       
    </style>
    <link rel="stylesheet" href="stylef.css">
</head>
<body>
<header>
        <h1>Bus Pass Management System</h1>
    </header>

    <nav>
        <a href="userhome.php">Home</a>
        <a href="userstatus.php">Status</a>
        <?php
        $qry="select pid from user_details where uid=$id";
        $res=mysqli_query($con,$qry);
        $row=mysqli_num_rows($res);
        if($row >0)
        {
            echo "<a>Purchase Pass</a>";
        }
        
        else
        {
           echo "<a href='purchasepass.php'>Purchase Pass</a>";
        }
        ?>
        <a href="userProfile.php">Profile</a>
        <a href="logout.php">Logout</a>
    </nav>
<?php
            $qry="select * from user_details where uid=$id";
            $res=mysqli_query($con,$qry);
            $row=mysqli_fetch_assoc($res);

            $uqry="select * from user where uid=$id";
            $ures=mysqli_query($con,$uqry);
            $urow=mysqli_fetch_assoc($ures);

            ?>
    <div id="profile-container">
        <div id="profile-header">
            <h1>User Profile</h1>
        </div>
        <br>
        
        <img src="<?php echo $row['uimg']?>" alt="Profile">
        <div id="user-details">
            
            <h2><?php echo $urow['uname'];?></h2>
            <p>Email: <?php echo $urow['uemail'];?></p>
            <p>Contact: <?php echo $urow['ucontact'];?></p>
        </div>
        
    </div>
</body>
</html>

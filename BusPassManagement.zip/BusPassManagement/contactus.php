<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bus Pass Management System - Home</title>
    <link rel="stylesheet" href="demo.css">
    <style>
       
        section {
            max-width: 800px;
            margin: 2em auto;
            background-color: #fff;
            padding: 2em;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>

    <header>
        <div class="hero">
            <h1>Welcome to Bus Pass Management System</h1>
           
        </div>
    </header>

    <nav>
        <a href="mainhome.php">Home</a>
        
        <a href="aboutus.php">About Us</a>
        <a href="contactus.php">Contact Us</a>
        <a href="userlogin.php">Login</a>
    </nav>

    <section>
        <h2>Our Contact Information</h2>
        <ul>
            <li><strong>Name:</strong> Akanksha</li>
            <li><strong>Phone:</strong> 972354xxxx</li>
            <li><strong>Email:</strong> ak@gmail.com</li>
        </ul>
      

    </section>
    <section>
        <h2>Our Contact Information</h2>
        <ul>
            <li><strong>Name:</strong> Kalpita</li>
            <li><strong>Phone:</strong> 989354xxxx</li>
            <li><strong>Email:</strong> kk@gmail.com</li>
        </ul>
      

    </section>



    
   
    
</body>
</html>
